﻿
namespace QuanLyNhaSach
{
    partial class UCKeSach
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCKeSach));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pbDangXuat = new System.Windows.Forms.PictureBox();
            this.lbHoTro = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dtgSach = new System.Windows.Forms.DataGridView();
            this.pnTT = new System.Windows.Forms.Panel();
            this.pnAn = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txbGiaTien = new System.Windows.Forms.TextBox();
            this.lbGiaTien = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txbTheLoai = new System.Windows.Forms.TextBox();
            this.txbTacGia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnSo = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pnNXB = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txbNXB = new System.Windows.Forms.TextBox();
            this.txbSo = new System.Windows.Forms.TextBox();
            this.txbMa = new System.Windows.Forms.TextBox();
            this.lbNXB = new System.Windows.Forms.Label();
            this.txbTen = new System.Windows.Forms.TextBox();
            this.lbSo = new System.Windows.Forms.Label();
            this.lbMa = new System.Windows.Forms.Label();
            this.lbTen = new System.Windows.Forms.Label();
            this.lbSoLuong = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbThuocTinh = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgSach)).BeginInit();
            this.pnTT.SuspendLayout();
            this.pnAn.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.panel1.Controls.Add(this.pbDangXuat);
            this.panel1.Controls.Add(this.lbHoTro);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 50);
            this.panel1.TabIndex = 3;
            // 
            // pbDangXuat
            // 
            this.pbDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("pbDangXuat.Image")));
            this.pbDangXuat.Location = new System.Drawing.Point(950, 0);
            this.pbDangXuat.Name = "pbDangXuat";
            this.pbDangXuat.Size = new System.Drawing.Size(50, 50);
            this.pbDangXuat.TabIndex = 2;
            this.pbDangXuat.TabStop = false;
            this.pbDangXuat.Click += new System.EventHandler(this.pbDangXuat_Click);
            // 
            // lbHoTro
            // 
            this.lbHoTro.AutoSize = true;
            this.lbHoTro.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoTro.ForeColor = System.Drawing.Color.White;
            this.lbHoTro.Location = new System.Drawing.Point(3, 12);
            this.lbHoTro.Name = "lbHoTro";
            this.lbHoTro.Size = new System.Drawing.Size(325, 25);
            this.lbHoTro.TabIndex = 1;
            this.lbHoTro.Text = "BỒ CÂU: \"Xin chào Trần Hữu Cảnh\"";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 670);
            this.panel2.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.pnTT);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1000, 670);
            this.panel4.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dtgSach);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 286);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1000, 384);
            this.panel6.TabIndex = 1;
            // 
            // dtgSach
            // 
            this.dtgSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgSach.BackgroundColor = System.Drawing.Color.White;
            this.dtgSach.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgSach.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgSach.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgSach.GridColor = System.Drawing.Color.White;
            this.dtgSach.Location = new System.Drawing.Point(0, 0);
            this.dtgSach.Margin = new System.Windows.Forms.Padding(0);
            this.dtgSach.Name = "dtgSach";
            this.dtgSach.ReadOnly = true;
            this.dtgSach.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgSach.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgSach.RowHeadersVisible = false;
            this.dtgSach.RowHeadersWidth = 51;
            this.dtgSach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.dtgSach.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dtgSach.RowTemplate.Height = 24;
            this.dtgSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgSach.Size = new System.Drawing.Size(1000, 384);
            this.dtgSach.TabIndex = 5;
            this.dtgSach.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgSach_CellContentClick);
            // 
            // pnTT
            // 
            this.pnTT.Controls.Add(this.pnAn);
            this.pnTT.Controls.Add(this.pnSo);
            this.pnTT.Controls.Add(this.panel16);
            this.pnTT.Controls.Add(this.pnNXB);
            this.pnTT.Controls.Add(this.panel17);
            this.pnTT.Controls.Add(this.txbNXB);
            this.pnTT.Controls.Add(this.txbSo);
            this.pnTT.Controls.Add(this.txbMa);
            this.pnTT.Controls.Add(this.lbNXB);
            this.pnTT.Controls.Add(this.txbTen);
            this.pnTT.Controls.Add(this.lbSo);
            this.pnTT.Controls.Add(this.lbMa);
            this.pnTT.Controls.Add(this.lbTen);
            this.pnTT.Controls.Add(this.lbSoLuong);
            this.pnTT.Controls.Add(this.label2);
            this.pnTT.Controls.Add(this.label1);
            this.pnTT.Controls.Add(this.cbThuocTinh);
            this.pnTT.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTT.Location = new System.Drawing.Point(0, 0);
            this.pnTT.Name = "pnTT";
            this.pnTT.Size = new System.Drawing.Size(1000, 286);
            this.pnTT.TabIndex = 0;
            // 
            // pnAn
            // 
            this.pnAn.Controls.Add(this.label5);
            this.pnAn.Controls.Add(this.panel15);
            this.pnAn.Controls.Add(this.txbGiaTien);
            this.pnAn.Controls.Add(this.lbGiaTien);
            this.pnAn.Controls.Add(this.panel7);
            this.pnAn.Controls.Add(this.panel3);
            this.pnAn.Controls.Add(this.txbTheLoai);
            this.pnAn.Controls.Add(this.txbTacGia);
            this.pnAn.Controls.Add(this.label6);
            this.pnAn.Controls.Add(this.label4);
            this.pnAn.Location = new System.Drawing.Point(545, 74);
            this.pnAn.Name = "pnAn";
            this.pnAn.Size = new System.Drawing.Size(429, 194);
            this.pnAn.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Location = new System.Drawing.Point(234, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 25);
            this.label5.TabIndex = 55;
            this.label5.Text = "VND";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel15.Location = new System.Drawing.Point(109, 121);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(119, 1);
            this.panel15.TabIndex = 54;
            // 
            // txbGiaTien
            // 
            this.txbGiaTien.BackColor = System.Drawing.Color.White;
            this.txbGiaTien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbGiaTien.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbGiaTien.ForeColor = System.Drawing.Color.Black;
            this.txbGiaTien.Location = new System.Drawing.Point(109, 97);
            this.txbGiaTien.Name = "txbGiaTien";
            this.txbGiaTien.ReadOnly = true;
            this.txbGiaTien.Size = new System.Drawing.Size(119, 26);
            this.txbGiaTien.TabIndex = 7;
            this.txbGiaTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbGiaTien
            // 
            this.lbGiaTien.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGiaTien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbGiaTien.Location = new System.Drawing.Point(2, 97);
            this.lbGiaTien.Name = "lbGiaTien";
            this.lbGiaTien.Size = new System.Drawing.Size(104, 30);
            this.lbGiaTien.TabIndex = 53;
            this.lbGiaTien.Text = "Giá Tiền:";
            this.lbGiaTien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel7.Location = new System.Drawing.Point(109, 80);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(288, 1);
            this.panel7.TabIndex = 50;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(109, 36);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(288, 1);
            this.panel3.TabIndex = 51;
            // 
            // txbTheLoai
            // 
            this.txbTheLoai.BackColor = System.Drawing.Color.White;
            this.txbTheLoai.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTheLoai.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTheLoai.ForeColor = System.Drawing.Color.Black;
            this.txbTheLoai.Location = new System.Drawing.Point(109, 56);
            this.txbTheLoai.Name = "txbTheLoai";
            this.txbTheLoai.ReadOnly = true;
            this.txbTheLoai.Size = new System.Drawing.Size(288, 26);
            this.txbTheLoai.TabIndex = 6;
            // 
            // txbTacGia
            // 
            this.txbTacGia.BackColor = System.Drawing.Color.White;
            this.txbTacGia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTacGia.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTacGia.ForeColor = System.Drawing.Color.Black;
            this.txbTacGia.Location = new System.Drawing.Point(109, 12);
            this.txbTacGia.Name = "txbTacGia";
            this.txbTacGia.ReadOnly = true;
            this.txbTacGia.Size = new System.Drawing.Size(288, 26);
            this.txbTacGia.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.label6.Location = new System.Drawing.Point(2, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 30);
            this.label6.TabIndex = 48;
            this.label6.Text = "Thể Loại:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.label4.Location = new System.Drawing.Point(2, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 30);
            this.label4.TabIndex = 49;
            this.label4.Text = "Tác Giả:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnSo
            // 
            this.pnSo.BackColor = System.Drawing.Color.Black;
            this.pnSo.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnSo.Location = new System.Drawing.Point(198, 196);
            this.pnSo.Name = "pnSo";
            this.pnSo.Size = new System.Drawing.Size(288, 1);
            this.pnSo.TabIndex = 39;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel16.Location = new System.Drawing.Point(198, 155);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(288, 1);
            this.panel16.TabIndex = 40;
            // 
            // pnNXB
            // 
            this.pnNXB.BackColor = System.Drawing.Color.Black;
            this.pnNXB.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnNXB.Location = new System.Drawing.Point(198, 238);
            this.pnNXB.Name = "pnNXB";
            this.pnNXB.Size = new System.Drawing.Size(288, 1);
            this.pnNXB.TabIndex = 41;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel17.Location = new System.Drawing.Point(198, 111);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(288, 1);
            this.panel17.TabIndex = 41;
            // 
            // txbNXB
            // 
            this.txbNXB.BackColor = System.Drawing.Color.White;
            this.txbNXB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNXB.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNXB.ForeColor = System.Drawing.Color.Black;
            this.txbNXB.Location = new System.Drawing.Point(198, 214);
            this.txbNXB.Name = "txbNXB";
            this.txbNXB.ReadOnly = true;
            this.txbNXB.Size = new System.Drawing.Size(288, 26);
            this.txbNXB.TabIndex = 3;
            // 
            // txbSo
            // 
            this.txbSo.BackColor = System.Drawing.Color.White;
            this.txbSo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbSo.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSo.ForeColor = System.Drawing.Color.Black;
            this.txbSo.Location = new System.Drawing.Point(199, 172);
            this.txbSo.Name = "txbSo";
            this.txbSo.Size = new System.Drawing.Size(288, 26);
            this.txbSo.TabIndex = 2;
            this.txbSo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txbMa
            // 
            this.txbMa.BackColor = System.Drawing.Color.White;
            this.txbMa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbMa.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMa.ForeColor = System.Drawing.Color.Black;
            this.txbMa.Location = new System.Drawing.Point(198, 131);
            this.txbMa.Name = "txbMa";
            this.txbMa.ReadOnly = true;
            this.txbMa.Size = new System.Drawing.Size(288, 26);
            this.txbMa.TabIndex = 1;
            // 
            // lbNXB
            // 
            this.lbNXB.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNXB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbNXB.Location = new System.Drawing.Point(34, 214);
            this.lbNXB.Name = "lbNXB";
            this.lbNXB.Size = new System.Drawing.Size(161, 30);
            this.lbNXB.TabIndex = 38;
            this.lbNXB.Text = "Nhà Xuất Bản:";
            this.lbNXB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txbTen
            // 
            this.txbTen.BackColor = System.Drawing.Color.White;
            this.txbTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTen.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTen.ForeColor = System.Drawing.Color.Black;
            this.txbTen.Location = new System.Drawing.Point(199, 87);
            this.txbTen.Name = "txbTen";
            this.txbTen.ReadOnly = true;
            this.txbTen.Size = new System.Drawing.Size(288, 26);
            this.txbTen.TabIndex = 0;
            // 
            // lbSo
            // 
            this.lbSo.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbSo.Location = new System.Drawing.Point(34, 172);
            this.lbSo.Name = "lbSo";
            this.lbSo.Size = new System.Drawing.Size(161, 30);
            this.lbSo.TabIndex = 36;
            this.lbSo.Text = "Số Lượng:";
            this.lbSo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbMa
            // 
            this.lbMa.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbMa.Location = new System.Drawing.Point(31, 131);
            this.lbMa.Name = "lbMa";
            this.lbMa.Size = new System.Drawing.Size(161, 30);
            this.lbMa.TabIndex = 37;
            this.lbMa.Text = "Mã Sách:";
            this.lbMa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTen
            // 
            this.lbTen.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbTen.Location = new System.Drawing.Point(31, 87);
            this.lbTen.Name = "lbTen";
            this.lbTen.Size = new System.Drawing.Size(161, 30);
            this.lbTen.TabIndex = 38;
            this.lbTen.Text = "Tên Sách:";
            this.lbTen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbSoLuong
            // 
            this.lbSoLuong.AutoSize = true;
            this.lbSoLuong.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoLuong.Location = new System.Drawing.Point(640, 33);
            this.lbSoLuong.Name = "lbSoLuong";
            this.lbSoLuong.Size = new System.Drawing.Size(25, 30);
            this.lbSoLuong.TabIndex = 5;
            this.lbSoLuong.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(529, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 30);
            this.label2.TabIndex = 5;
            this.label2.Text = "Số Lượng:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 30);
            this.label1.TabIndex = 5;
            this.label1.Text = "Chọn thuộc tính:";
            // 
            // cbThuocTinh
            // 
            this.cbThuocTinh.BackColor = System.Drawing.SystemColors.Control;
            this.cbThuocTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbThuocTinh.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbThuocTinh.FormattingEnabled = true;
            this.cbThuocTinh.Items.AddRange(new object[] {
            "Sách",
            "Tác Giả",
            "Thể Loại",
            "Nhà Xuất Bản"});
            this.cbThuocTinh.Location = new System.Drawing.Point(256, 30);
            this.cbThuocTinh.Name = "cbThuocTinh";
            this.cbThuocTinh.Size = new System.Drawing.Size(247, 38);
            this.cbThuocTinh.TabIndex = 4;
            this.cbThuocTinh.SelectedIndexChanged += new System.EventHandler(this.cbThuocTinh_SelectedIndexChanged);
            // 
            // UCKeSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "UCKeSach";
            this.Size = new System.Drawing.Size(1000, 720);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgSach)).EndInit();
            this.pnTT.ResumeLayout(false);
            this.pnTT.PerformLayout();
            this.pnAn.ResumeLayout(false);
            this.pnAn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbDangXuat;
        private System.Windows.Forms.Label lbHoTro;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel pnTT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbThuocTinh;
        private System.Windows.Forms.DataGridView dtgSach;
        private System.Windows.Forms.Panel pnSo;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel pnNXB;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txbNXB;
        private System.Windows.Forms.TextBox txbSo;
        private System.Windows.Forms.TextBox txbMa;
        private System.Windows.Forms.Label lbNXB;
        private System.Windows.Forms.TextBox txbTen;
        private System.Windows.Forms.Label lbSo;
        private System.Windows.Forms.Label lbMa;
        private System.Windows.Forms.Label lbTen;
        private System.Windows.Forms.Panel pnAn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txbGiaTien;
        private System.Windows.Forms.Label lbGiaTien;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txbTheLoai;
        private System.Windows.Forms.TextBox txbTacGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbSoLuong;
        private System.Windows.Forms.Label label2;
    }
}
