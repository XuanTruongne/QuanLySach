﻿
namespace QuanLyNhaSach
{
    partial class UCCaiDat
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCCaiDat));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.grbThongTinTaiKhoan = new System.Windows.Forms.GroupBox();
            this.grbPhanQuyen = new System.Windows.Forms.GroupBox();
            this.ckbThemDL = new System.Windows.Forms.CheckBox();
            this.ckbKeSach = new System.Windows.Forms.CheckBox();
            this.ckbTaiKhoan = new System.Windows.Forms.CheckBox();
            this.ckbNhapSach = new System.Windows.Forms.CheckBox();
            this.ckbBanSach = new System.Windows.Forms.CheckBox();
            this.ckbThongKe = new System.Windows.Forms.CheckBox();
            this.pnMKM = new System.Windows.Forms.Panel();
            this.txbMatKhauMoi = new System.Windows.Forms.TextBox();
            this.pnNL = new System.Windows.Forms.Panel();
            this.txbNhapLaiMKM = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbMatKhau = new System.Windows.Forms.TextBox();
            this.txbTenHT = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbTenDN = new System.Windows.Forms.TextBox();
            this.lbNL = new System.Windows.Forms.Label();
            this.lbMKM = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbTenSach = new System.Windows.Forms.Label();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnThemTaiKhoan = new System.Windows.Forms.Button();
            this.cbTaiKhoan = new System.Windows.Forms.ComboBox();
            this.btnXoa = new System.Windows.Forms.Button();
            this.lbHoTro = new System.Windows.Forms.Label();
            this.pbDangXuat = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grbThongTinTaiKhoan.SuspendLayout();
            this.grbPhanQuyen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 670);
            this.panel2.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.grbThongTinTaiKhoan);
            this.panel4.Controls.Add(this.btnThemTaiKhoan);
            this.panel4.Controls.Add(this.cbTaiKhoan);
            this.panel4.Controls.Add(this.btnXoa);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1000, 670);
            this.panel4.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 30);
            this.label1.TabIndex = 3;
            this.label1.Text = "Chọn tài khoản:";
            // 
            // grbThongTinTaiKhoan
            // 
            this.grbThongTinTaiKhoan.Controls.Add(this.grbPhanQuyen);
            this.grbThongTinTaiKhoan.Controls.Add(this.pnMKM);
            this.grbThongTinTaiKhoan.Controls.Add(this.txbMatKhauMoi);
            this.grbThongTinTaiKhoan.Controls.Add(this.pnNL);
            this.grbThongTinTaiKhoan.Controls.Add(this.txbNhapLaiMKM);
            this.grbThongTinTaiKhoan.Controls.Add(this.panel3);
            this.grbThongTinTaiKhoan.Controls.Add(this.panel7);
            this.grbThongTinTaiKhoan.Controls.Add(this.txbMatKhau);
            this.grbThongTinTaiKhoan.Controls.Add(this.txbTenHT);
            this.grbThongTinTaiKhoan.Controls.Add(this.panel8);
            this.grbThongTinTaiKhoan.Controls.Add(this.txbTenDN);
            this.grbThongTinTaiKhoan.Controls.Add(this.lbNL);
            this.grbThongTinTaiKhoan.Controls.Add(this.lbMKM);
            this.grbThongTinTaiKhoan.Controls.Add(this.label2);
            this.grbThongTinTaiKhoan.Controls.Add(this.label5);
            this.grbThongTinTaiKhoan.Controls.Add(this.lbTenSach);
            this.grbThongTinTaiKhoan.Controls.Add(this.btnLuu);
            this.grbThongTinTaiKhoan.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grbThongTinTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grbThongTinTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTinTaiKhoan.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.grbThongTinTaiKhoan.Location = new System.Drawing.Point(0, 95);
            this.grbThongTinTaiKhoan.Name = "grbThongTinTaiKhoan";
            this.grbThongTinTaiKhoan.Size = new System.Drawing.Size(1000, 575);
            this.grbThongTinTaiKhoan.TabIndex = 2;
            this.grbThongTinTaiKhoan.TabStop = false;
            this.grbThongTinTaiKhoan.Text = "THÔNG TIN TÀI KHOẢN";
            // 
            // grbPhanQuyen
            // 
            this.grbPhanQuyen.Controls.Add(this.ckbThemDL);
            this.grbPhanQuyen.Controls.Add(this.ckbKeSach);
            this.grbPhanQuyen.Controls.Add(this.ckbTaiKhoan);
            this.grbPhanQuyen.Controls.Add(this.ckbNhapSach);
            this.grbPhanQuyen.Controls.Add(this.ckbBanSach);
            this.grbPhanQuyen.Controls.Add(this.ckbThongKe);
            this.grbPhanQuyen.Dock = System.Windows.Forms.DockStyle.Right;
            this.grbPhanQuyen.Location = new System.Drawing.Point(737, 29);
            this.grbPhanQuyen.Name = "grbPhanQuyen";
            this.grbPhanQuyen.Size = new System.Drawing.Size(260, 543);
            this.grbPhanQuyen.TabIndex = 43;
            this.grbPhanQuyen.TabStop = false;
            this.grbPhanQuyen.Text = "Phân Quyền";
            // 
            // ckbThemDL
            // 
            this.ckbThemDL.AutoSize = true;
            this.ckbThemDL.Location = new System.Drawing.Point(18, 448);
            this.ckbThemDL.Name = "ckbThemDL";
            this.ckbThemDL.Size = new System.Drawing.Size(154, 29);
            this.ckbThemDL.TabIndex = 12;
            this.ckbThemDL.Text = "Thêm Dữ Liệu";
            this.ckbThemDL.UseVisualStyleBackColor = true;
            // 
            // ckbKeSach
            // 
            this.ckbKeSach.AutoSize = true;
            this.ckbKeSach.Location = new System.Drawing.Point(18, 364);
            this.ckbKeSach.Name = "ckbKeSach";
            this.ckbKeSach.Size = new System.Drawing.Size(99, 29);
            this.ckbKeSach.TabIndex = 11;
            this.ckbKeSach.Text = "Kệ Sách";
            this.ckbKeSach.UseVisualStyleBackColor = true;
            // 
            // ckbTaiKhoan
            // 
            this.ckbTaiKhoan.AutoSize = true;
            this.ckbTaiKhoan.Location = new System.Drawing.Point(18, 142);
            this.ckbTaiKhoan.Name = "ckbTaiKhoan";
            this.ckbTaiKhoan.Size = new System.Drawing.Size(213, 29);
            this.ckbTaiKhoan.TabIndex = 8;
            this.ckbTaiKhoan.Text = "Thông Tin Tài Khoản";
            this.ckbTaiKhoan.UseVisualStyleBackColor = true;
            // 
            // ckbNhapSach
            // 
            this.ckbNhapSach.AutoSize = true;
            this.ckbNhapSach.Location = new System.Drawing.Point(18, 284);
            this.ckbNhapSach.Name = "ckbNhapSach";
            this.ckbNhapSach.Size = new System.Drawing.Size(125, 29);
            this.ckbNhapSach.TabIndex = 10;
            this.ckbNhapSach.Text = "Nhập Sách";
            this.ckbNhapSach.UseVisualStyleBackColor = true;
            // 
            // ckbBanSach
            // 
            this.ckbBanSach.AutoSize = true;
            this.ckbBanSach.Location = new System.Drawing.Point(18, 67);
            this.ckbBanSach.Name = "ckbBanSach";
            this.ckbBanSach.Size = new System.Drawing.Size(111, 29);
            this.ckbBanSach.TabIndex = 7;
            this.ckbBanSach.Text = "Bán Sách";
            this.ckbBanSach.UseVisualStyleBackColor = true;
            // 
            // ckbThongKe
            // 
            this.ckbThongKe.AutoSize = true;
            this.ckbThongKe.Location = new System.Drawing.Point(18, 209);
            this.ckbThongKe.Name = "ckbThongKe";
            this.ckbThongKe.Size = new System.Drawing.Size(116, 29);
            this.ckbThongKe.TabIndex = 9;
            this.ckbThongKe.Text = "Thống Kê";
            this.ckbThongKe.UseVisualStyleBackColor = true;
            // 
            // pnMKM
            // 
            this.pnMKM.BackColor = System.Drawing.Color.Black;
            this.pnMKM.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnMKM.Location = new System.Drawing.Point(273, 341);
            this.pnMKM.Margin = new System.Windows.Forms.Padding(2);
            this.pnMKM.Name = "pnMKM";
            this.pnMKM.Size = new System.Drawing.Size(390, 1);
            this.pnMKM.TabIndex = 38;
            // 
            // txbMatKhauMoi
            // 
            this.txbMatKhauMoi.BackColor = System.Drawing.Color.White;
            this.txbMatKhauMoi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbMatKhauMoi.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMatKhauMoi.Location = new System.Drawing.Point(274, 308);
            this.txbMatKhauMoi.Margin = new System.Windows.Forms.Padding(2);
            this.txbMatKhauMoi.Name = "txbMatKhauMoi";
            this.txbMatKhauMoi.Size = new System.Drawing.Size(390, 32);
            this.txbMatKhauMoi.TabIndex = 4;
            this.txbMatKhauMoi.UseSystemPasswordChar = true;
            // 
            // pnNL
            // 
            this.pnNL.BackColor = System.Drawing.Color.Black;
            this.pnNL.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnNL.Location = new System.Drawing.Point(275, 411);
            this.pnNL.Margin = new System.Windows.Forms.Padding(2);
            this.pnNL.Name = "pnNL";
            this.pnNL.Size = new System.Drawing.Size(390, 1);
            this.pnNL.TabIndex = 39;
            // 
            // txbNhapLaiMKM
            // 
            this.txbNhapLaiMKM.BackColor = System.Drawing.Color.White;
            this.txbNhapLaiMKM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNhapLaiMKM.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNhapLaiMKM.Location = new System.Drawing.Point(277, 378);
            this.txbNhapLaiMKM.Margin = new System.Windows.Forms.Padding(2);
            this.txbNhapLaiMKM.Name = "txbNhapLaiMKM";
            this.txbNhapLaiMKM.Size = new System.Drawing.Size(390, 32);
            this.txbNhapLaiMKM.TabIndex = 5;
            this.txbNhapLaiMKM.UseSystemPasswordChar = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(273, 271);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(390, 1);
            this.panel3.TabIndex = 40;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel7.Location = new System.Drawing.Point(271, 201);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(390, 1);
            this.panel7.TabIndex = 41;
            // 
            // txbMatKhau
            // 
            this.txbMatKhau.BackColor = System.Drawing.Color.White;
            this.txbMatKhau.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbMatKhau.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMatKhau.Location = new System.Drawing.Point(275, 237);
            this.txbMatKhau.Margin = new System.Windows.Forms.Padding(2);
            this.txbMatKhau.Name = "txbMatKhau";
            this.txbMatKhau.Size = new System.Drawing.Size(390, 32);
            this.txbMatKhau.TabIndex = 3;
            this.txbMatKhau.UseSystemPasswordChar = true;
            // 
            // txbTenHT
            // 
            this.txbTenHT.BackColor = System.Drawing.Color.White;
            this.txbTenHT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTenHT.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTenHT.Location = new System.Drawing.Point(273, 168);
            this.txbTenHT.Margin = new System.Windows.Forms.Padding(2);
            this.txbTenHT.Name = "txbTenHT";
            this.txbTenHT.Size = new System.Drawing.Size(390, 32);
            this.txbTenHT.TabIndex = 2;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel8.Location = new System.Drawing.Point(273, 126);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(390, 1);
            this.panel8.TabIndex = 42;
            // 
            // txbTenDN
            // 
            this.txbTenDN.BackColor = System.Drawing.Color.White;
            this.txbTenDN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTenDN.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTenDN.Location = new System.Drawing.Point(275, 93);
            this.txbTenDN.Margin = new System.Windows.Forms.Padding(2);
            this.txbTenDN.Name = "txbTenDN";
            this.txbTenDN.ReadOnly = true;
            this.txbTenDN.Size = new System.Drawing.Size(390, 32);
            this.txbTenDN.TabIndex = 1;
            // 
            // lbNL
            // 
            this.lbNL.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbNL.Location = new System.Drawing.Point(37, 371);
            this.lbNL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNL.Name = "lbNL";
            this.lbNL.Size = new System.Drawing.Size(234, 42);
            this.lbNL.TabIndex = 35;
            this.lbNL.Text = "Nhập lại:";
            this.lbNL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbMKM
            // 
            this.lbMKM.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMKM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbMKM.Location = new System.Drawing.Point(35, 301);
            this.lbMKM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbMKM.Name = "lbMKM";
            this.lbMKM.Size = new System.Drawing.Size(234, 42);
            this.lbMKM.TabIndex = 34;
            this.lbMKM.Text = "Mật khẩu mới:";
            this.lbMKM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.label2.Location = new System.Drawing.Point(35, 230);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(234, 42);
            this.label2.TabIndex = 33;
            this.label2.Text = "Mật khẩu:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.label5.Location = new System.Drawing.Point(33, 161);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(234, 42);
            this.label5.TabIndex = 37;
            this.label5.Text = "Tên hiển thị:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTenSach
            // 
            this.lbTenSach.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbTenSach.Location = new System.Drawing.Point(35, 86);
            this.lbTenSach.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTenSach.Name = "lbTenSach";
            this.lbTenSach.Size = new System.Drawing.Size(234, 42);
            this.lbTenSach.TabIndex = 36;
            this.lbTenSach.Text = "Tên đăng nhập:";
            this.lbTenSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.PaleGreen;
            this.btnLuu.FlatAppearance.BorderSize = 0;
            this.btnLuu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuu.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.Color.Black;
            this.btnLuu.Location = new System.Drawing.Point(106, 493);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(195, 47);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "LƯU";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnThemTaiKhoan
            // 
            this.btnThemTaiKhoan.BackColor = System.Drawing.Color.PaleGreen;
            this.btnThemTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btnThemTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTaiKhoan.Location = new System.Drawing.Point(798, 33);
            this.btnThemTaiKhoan.Name = "btnThemTaiKhoan";
            this.btnThemTaiKhoan.Size = new System.Drawing.Size(180, 40);
            this.btnThemTaiKhoan.TabIndex = 1;
            this.btnThemTaiKhoan.Text = "Thêm Tài Khoản";
            this.btnThemTaiKhoan.UseVisualStyleBackColor = false;
            this.btnThemTaiKhoan.Click += new System.EventHandler(this.btnThemTaiKhoan_Click);
            // 
            // cbTaiKhoan
            // 
            this.cbTaiKhoan.BackColor = System.Drawing.SystemColors.Control;
            this.cbTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTaiKhoan.FormattingEnabled = true;
            this.cbTaiKhoan.Location = new System.Drawing.Point(188, 30);
            this.cbTaiKhoan.Name = "cbTaiKhoan";
            this.cbTaiKhoan.Size = new System.Drawing.Size(247, 38);
            this.cbTaiKhoan.TabIndex = 0;
            this.cbTaiKhoan.SelectedIndexChanged += new System.EventHandler(this.cbTaiKhoan_SelectedIndexChanged);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Red;
            this.btnXoa.FlatAppearance.BorderSize = 0;
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.Color.Black;
            this.btnXoa.Location = new System.Drawing.Point(546, 33);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(180, 40);
            this.btnXoa.TabIndex = 1;
            this.btnXoa.Text = "Xóa Tài Khoản";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // lbHoTro
            // 
            this.lbHoTro.AutoSize = true;
            this.lbHoTro.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoTro.ForeColor = System.Drawing.Color.White;
            this.lbHoTro.Location = new System.Drawing.Point(3, 12);
            this.lbHoTro.Name = "lbHoTro";
            this.lbHoTro.Size = new System.Drawing.Size(325, 25);
            this.lbHoTro.TabIndex = 1;
            this.lbHoTro.Text = "BỒ CÂU: \"Xin chào Trần Hữu Cảnh\"";
            // 
            // pbDangXuat
            // 
            this.pbDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("pbDangXuat.Image")));
            this.pbDangXuat.Location = new System.Drawing.Point(950, 0);
            this.pbDangXuat.Name = "pbDangXuat";
            this.pbDangXuat.Size = new System.Drawing.Size(50, 50);
            this.pbDangXuat.TabIndex = 2;
            this.pbDangXuat.TabStop = false;
            this.pbDangXuat.Click += new System.EventHandler(this.pbDangXuat_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.panel1.Controls.Add(this.pbDangXuat);
            this.panel1.Controls.Add(this.lbHoTro);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 50);
            this.panel1.TabIndex = 2;
            // 
            // UCCaiDat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "UCCaiDat";
            this.Size = new System.Drawing.Size(1000, 720);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.grbThongTinTaiKhoan.ResumeLayout(false);
            this.grbThongTinTaiKhoan.PerformLayout();
            this.grbPhanQuyen.ResumeLayout(false);
            this.grbPhanQuyen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cbTaiKhoan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grbThongTinTaiKhoan;
        private System.Windows.Forms.Button btnThemTaiKhoan;
        private System.Windows.Forms.Label lbHoTro;
        private System.Windows.Forms.PictureBox pbDangXuat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.GroupBox grbPhanQuyen;
        private System.Windows.Forms.CheckBox ckbThemDL;
        private System.Windows.Forms.CheckBox ckbKeSach;
        private System.Windows.Forms.CheckBox ckbNhapSach;
        private System.Windows.Forms.CheckBox ckbThongKe;
        private System.Windows.Forms.Panel pnMKM;
        private System.Windows.Forms.TextBox txbMatKhauMoi;
        private System.Windows.Forms.Panel pnNL;
        private System.Windows.Forms.TextBox txbNhapLaiMKM;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbMatKhau;
        private System.Windows.Forms.TextBox txbTenHT;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbTenDN;
        private System.Windows.Forms.Label lbNL;
        private System.Windows.Forms.Label lbMKM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.CheckBox ckbTaiKhoan;
        private System.Windows.Forms.CheckBox ckbBanSach;
        private System.Windows.Forms.Button btnXoa;
    }
}
