﻿
namespace QuanLyNhaSach
{
    partial class UCThemDuLieu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCThemDuLieu));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pbDangXuat = new System.Windows.Forms.PictureBox();
            this.lbHoTro = new System.Windows.Forms.Label();
            this.pnTT = new System.Windows.Forms.Panel();
            this.btnThem = new System.Windows.Forms.Button();
            this.pnTG = new System.Windows.Forms.Panel();
            this.panelTL = new System.Windows.Forms.Panel();
            this.panelTG = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbDC = new System.Windows.Forms.TextBox();
            this.lbDC = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbSo = new System.Windows.Forms.Label();
            this.txbSo = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbMa = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txbTen = new System.Windows.Forms.TextBox();
            this.lbTen = new System.Windows.Forms.Label();
            this.lbMa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbThuocTinh = new System.Windows.Forms.ComboBox();
            this.dtgSach = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).BeginInit();
            this.pnTT.SuspendLayout();
            this.pnTG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgSach)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.panel1.Controls.Add(this.pbDangXuat);
            this.panel1.Controls.Add(this.lbHoTro);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(750, 41);
            this.panel1.TabIndex = 4;
            // 
            // pbDangXuat
            // 
            this.pbDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("pbDangXuat.Image")));
            this.pbDangXuat.Location = new System.Drawing.Point(712, 0);
            this.pbDangXuat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbDangXuat.Name = "pbDangXuat";
            this.pbDangXuat.Size = new System.Drawing.Size(38, 41);
            this.pbDangXuat.TabIndex = 2;
            this.pbDangXuat.TabStop = false;
            this.pbDangXuat.Click += new System.EventHandler(this.pbDangXuat_Click);
            // 
            // lbHoTro
            // 
            this.lbHoTro.AutoSize = true;
            this.lbHoTro.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHoTro.ForeColor = System.Drawing.Color.White;
            this.lbHoTro.Location = new System.Drawing.Point(2, 10);
            this.lbHoTro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbHoTro.Name = "lbHoTro";
            this.lbHoTro.Size = new System.Drawing.Size(325, 25);
            this.lbHoTro.TabIndex = 1;
            this.lbHoTro.Text = "BỒ CÂU: \"Xin chào Trần Hữu Cảnh\"";
            // 
            // pnTT
            // 
            this.pnTT.Controls.Add(this.btnThem);
            this.pnTT.Controls.Add(this.pnTG);
            this.pnTT.Controls.Add(this.label1);
            this.pnTT.Controls.Add(this.cbThuocTinh);
            this.pnTT.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTT.Location = new System.Drawing.Point(0, 41);
            this.pnTT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnTT.Name = "pnTT";
            this.pnTT.Size = new System.Drawing.Size(750, 232);
            this.pnTT.TabIndex = 5;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Location = new System.Drawing.Point(561, 117);
            this.btnThem.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(144, 42);
            this.btnThem.TabIndex = 46;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // pnTG
            // 
            this.pnTG.Controls.Add(this.panelTL);
            this.pnTG.Controls.Add(this.panelTG);
            this.pnTG.Controls.Add(this.panel2);
            this.pnTG.Controls.Add(this.txbDC);
            this.pnTG.Controls.Add(this.lbDC);
            this.pnTG.Controls.Add(this.panel9);
            this.pnTG.Controls.Add(this.lbSo);
            this.pnTG.Controls.Add(this.txbSo);
            this.pnTG.Controls.Add(this.panel8);
            this.pnTG.Controls.Add(this.txbMa);
            this.pnTG.Controls.Add(this.panel4);
            this.pnTG.Controls.Add(this.txbTen);
            this.pnTG.Controls.Add(this.lbTen);
            this.pnTG.Controls.Add(this.lbMa);
            this.pnTG.Location = new System.Drawing.Point(0, 66);
            this.pnTG.Margin = new System.Windows.Forms.Padding(2);
            this.pnTG.Name = "pnTG";
            this.pnTG.Size = new System.Drawing.Size(518, 164);
            this.pnTG.TabIndex = 45;
            // 
            // panelTL
            // 
            this.panelTL.Location = new System.Drawing.Point(82, 89);
            this.panelTL.Margin = new System.Windows.Forms.Padding(2);
            this.panelTL.Name = "panelTL";
            this.panelTL.Size = new System.Drawing.Size(421, 77);
            this.panelTL.TabIndex = 47;
            // 
            // panelTG
            // 
            this.panelTG.Location = new System.Drawing.Point(118, 139);
            this.panelTG.Margin = new System.Windows.Forms.Padding(2);
            this.panelTG.Name = "panelTG";
            this.panelTG.Size = new System.Drawing.Size(316, 27);
            this.panelTG.TabIndex = 46;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(201, 161);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(216, 1);
            this.panel2.TabIndex = 54;
            // 
            // txbDC
            // 
            this.txbDC.BackColor = System.Drawing.Color.White;
            this.txbDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbDC.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbDC.ForeColor = System.Drawing.Color.Black;
            this.txbDC.Location = new System.Drawing.Point(201, 141);
            this.txbDC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txbDC.Name = "txbDC";
            this.txbDC.Size = new System.Drawing.Size(216, 26);
            this.txbDC.TabIndex = 53;
            // 
            // lbDC
            // 
            this.lbDC.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbDC.Location = new System.Drawing.Point(62, 137);
            this.lbDC.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbDC.Name = "lbDC";
            this.lbDC.Size = new System.Drawing.Size(121, 24);
            this.lbDC.TabIndex = 52;
            this.lbDC.Text = "Địa Chỉ:";
            this.lbDC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel9.Location = new System.Drawing.Point(201, 121);
            this.panel9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(216, 1);
            this.panel9.TabIndex = 51;
            // 
            // lbSo
            // 
            this.lbSo.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbSo.Location = new System.Drawing.Point(62, 97);
            this.lbSo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSo.Name = "lbSo";
            this.lbSo.Size = new System.Drawing.Size(121, 24);
            this.lbSo.TabIndex = 49;
            this.lbSo.Text = "Số Điện Thoại:";
            this.lbSo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txbSo
            // 
            this.txbSo.BackColor = System.Drawing.Color.White;
            this.txbSo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbSo.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSo.ForeColor = System.Drawing.Color.Black;
            this.txbSo.Location = new System.Drawing.Point(200, 101);
            this.txbSo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txbSo.Name = "txbSo";
            this.txbSo.Size = new System.Drawing.Size(216, 26);
            this.txbSo.TabIndex = 50;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel8.Location = new System.Drawing.Point(200, 80);
            this.panel8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(216, 1);
            this.panel8.TabIndex = 48;
            // 
            // txbMa
            // 
            this.txbMa.BackColor = System.Drawing.Color.White;
            this.txbMa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbMa.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbMa.ForeColor = System.Drawing.Color.Black;
            this.txbMa.Location = new System.Drawing.Point(200, 60);
            this.txbMa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txbMa.Name = "txbMa";
            this.txbMa.Size = new System.Drawing.Size(216, 26);
            this.txbMa.TabIndex = 47;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(201, 41);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(216, 1);
            this.panel4.TabIndex = 46;
            // 
            // txbTen
            // 
            this.txbTen.BackColor = System.Drawing.Color.White;
            this.txbTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTen.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTen.ForeColor = System.Drawing.Color.Black;
            this.txbTen.Location = new System.Drawing.Point(201, 20);
            this.txbTen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txbTen.Name = "txbTen";
            this.txbTen.Size = new System.Drawing.Size(216, 26);
            this.txbTen.TabIndex = 45;
            // 
            // lbTen
            // 
            this.lbTen.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbTen.Location = new System.Drawing.Point(62, 20);
            this.lbTen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTen.Name = "lbTen";
            this.lbTen.Size = new System.Drawing.Size(121, 22);
            this.lbTen.TabIndex = 38;
            this.lbTen.Text = "Tên Tác Giả:";
            this.lbTen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbMa
            // 
            this.lbMa.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lbMa.Location = new System.Drawing.Point(62, 57);
            this.lbMa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbMa.Name = "lbMa";
            this.lbMa.Size = new System.Drawing.Size(121, 24);
            this.lbMa.TabIndex = 37;
            this.lbMa.Text = "Mã Tác Giả:";
            this.lbMa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 30);
            this.label1.TabIndex = 5;
            this.label1.Text = "Chọn thuộc tính:";
            // 
            // cbThuocTinh
            // 
            this.cbThuocTinh.BackColor = System.Drawing.SystemColors.Control;
            this.cbThuocTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbThuocTinh.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbThuocTinh.FormattingEnabled = true;
            this.cbThuocTinh.Items.AddRange(new object[] {
            "Tác Giả",
            "Thể Loại",
            "Nhà Xuất Bản"});
            this.cbThuocTinh.Location = new System.Drawing.Point(236, 24);
            this.cbThuocTinh.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbThuocTinh.Name = "cbThuocTinh";
            this.cbThuocTinh.Size = new System.Drawing.Size(186, 38);
            this.cbThuocTinh.TabIndex = 4;
            this.cbThuocTinh.SelectedIndexChanged += new System.EventHandler(this.cbThuocTinh_SelectedIndexChanged);
            // 
            // dtgSach
            // 
            this.dtgSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgSach.BackgroundColor = System.Drawing.Color.White;
            this.dtgSach.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgSach.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dtgSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgSach.DefaultCellStyle = dataGridViewCellStyle6;
            this.dtgSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgSach.GridColor = System.Drawing.Color.White;
            this.dtgSach.Location = new System.Drawing.Point(0, 273);
            this.dtgSach.Margin = new System.Windows.Forms.Padding(0);
            this.dtgSach.Name = "dtgSach";
            this.dtgSach.ReadOnly = true;
            this.dtgSach.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgSach.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dtgSach.RowHeadersVisible = false;
            this.dtgSach.RowHeadersWidth = 51;
            this.dtgSach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            this.dtgSach.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dtgSach.RowTemplate.Height = 24;
            this.dtgSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgSach.Size = new System.Drawing.Size(750, 312);
            this.dtgSach.TabIndex = 6;
            this.dtgSach.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgSach_CellContentClick);
            // 
            // UCThemDuLieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dtgSach);
            this.Controls.Add(this.pnTT);
            this.Controls.Add(this.panel1);
            this.Name = "UCThemDuLieu";
            this.Size = new System.Drawing.Size(750, 585);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDangXuat)).EndInit();
            this.pnTT.ResumeLayout(false);
            this.pnTT.PerformLayout();
            this.pnTG.ResumeLayout(false);
            this.pnTG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgSach)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbDangXuat;
        private System.Windows.Forms.Label lbHoTro;
        private System.Windows.Forms.Panel pnTT;
        private System.Windows.Forms.Label lbMa;
        private System.Windows.Forms.Label lbTen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbThuocTinh;
        private System.Windows.Forms.DataGridView dtgSach;
        private System.Windows.Forms.Panel pnTG;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txbTen;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txbSo;
        private System.Windows.Forms.Label lbSo;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbMa;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbDC;
        private System.Windows.Forms.Label lbDC;
        private System.Windows.Forms.Panel panelTL;
        private System.Windows.Forms.Panel panelTG;
        private System.Windows.Forms.Button btnThem;
    }
}
