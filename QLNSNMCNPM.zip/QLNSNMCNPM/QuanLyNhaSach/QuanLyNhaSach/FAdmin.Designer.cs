﻿namespace QuanLyNhaSach
{
    partial class FAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txbGiaTien = new System.Windows.Forms.TextBox();
            this.txbTacGia = new System.Windows.Forms.TextBox();
            this.txbSoLuong = new System.Windows.Forms.TextBox();
            this.txbTenSach = new System.Windows.Forms.TextBox();
            this.txbNXB = new System.Windows.Forms.TextBox();
            this.txbLoaiSach = new System.Windows.Forms.TextBox();
            this.lbGiaTien = new System.Windows.Forms.Label();
            this.lbTacGia = new System.Windows.Forms.Label();
            this.lbSoLuong = new System.Windows.Forms.Label();
            this.lbTenSach = new System.Windows.Forms.Label();
            this.lbNXB = new System.Windows.Forms.Label();
            this.lbLoaiSach = new System.Windows.Forms.Label();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.txbGiaTien);
            this.panel2.Controls.Add(this.txbTacGia);
            this.panel2.Controls.Add(this.txbSoLuong);
            this.panel2.Controls.Add(this.txbTenSach);
            this.panel2.Controls.Add(this.txbNXB);
            this.panel2.Controls.Add(this.txbLoaiSach);
            this.panel2.Controls.Add(this.lbGiaTien);
            this.panel2.Controls.Add(this.lbTacGia);
            this.panel2.Controls.Add(this.lbSoLuong);
            this.panel2.Controls.Add(this.lbTenSach);
            this.panel2.Controls.Add(this.lbNXB);
            this.panel2.Controls.Add(this.lbLoaiSach);
            this.panel2.Controls.Add(this.btnXoa);
            this.panel2.Controls.Add(this.btnSua);
            this.panel2.Controls.Add(this.btnThem);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1182, 261);
            this.panel2.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(714, 220);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(240, 1);
            this.panel8.TabIndex = 7;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(200, 220);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(240, 1);
            this.panel5.TabIndex = 7;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(714, 148);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(240, 1);
            this.panel7.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(200, 148);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(240, 1);
            this.panel4.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(714, 69);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(240, 1);
            this.panel6.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(200, 69);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(240, 1);
            this.panel3.TabIndex = 7;
            // 
            // txbGiaTien
            // 
            this.txbGiaTien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbGiaTien.Location = new System.Drawing.Point(714, 193);
            this.txbGiaTien.Name = "txbGiaTien";
            this.txbGiaTien.Size = new System.Drawing.Size(240, 15);
            this.txbGiaTien.TabIndex = 6;
            // 
            // txbTacGia
            // 
            this.txbTacGia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTacGia.Location = new System.Drawing.Point(200, 193);
            this.txbTacGia.Name = "txbTacGia";
            this.txbTacGia.Size = new System.Drawing.Size(240, 15);
            this.txbTacGia.TabIndex = 3;
            // 
            // txbSoLuong
            // 
            this.txbSoLuong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbSoLuong.Location = new System.Drawing.Point(714, 121);
            this.txbSoLuong.Name = "txbSoLuong";
            this.txbSoLuong.Size = new System.Drawing.Size(240, 15);
            this.txbSoLuong.TabIndex = 5;
            // 
            // txbTenSach
            // 
            this.txbTenSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTenSach.Location = new System.Drawing.Point(200, 121);
            this.txbTenSach.Name = "txbTenSach";
            this.txbTenSach.Size = new System.Drawing.Size(240, 15);
            this.txbTenSach.TabIndex = 2;
            // 
            // txbNXB
            // 
            this.txbNXB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNXB.Location = new System.Drawing.Point(714, 42);
            this.txbNXB.Name = "txbNXB";
            this.txbNXB.Size = new System.Drawing.Size(240, 15);
            this.txbNXB.TabIndex = 4;
            // 
            // txbLoaiSach
            // 
            this.txbLoaiSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbLoaiSach.Location = new System.Drawing.Point(200, 42);
            this.txbLoaiSach.Name = "txbLoaiSach";
            this.txbLoaiSach.Size = new System.Drawing.Size(240, 15);
            this.txbLoaiSach.TabIndex = 1;
            // 
            // lbGiaTien
            // 
            this.lbGiaTien.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGiaTien.ForeColor = System.Drawing.Color.DarkBlue;
            this.lbGiaTien.Location = new System.Drawing.Point(558, 192);
            this.lbGiaTien.Name = "lbGiaTien";
            this.lbGiaTien.Size = new System.Drawing.Size(150, 30);
            this.lbGiaTien.TabIndex = 5;
            this.lbGiaTien.Text = "Giá Tiền:";
            this.lbGiaTien.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTacGia
            // 
            this.lbTacGia.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTacGia.ForeColor = System.Drawing.Color.Navy;
            this.lbTacGia.Location = new System.Drawing.Point(43, 192);
            this.lbTacGia.Name = "lbTacGia";
            this.lbTacGia.Size = new System.Drawing.Size(150, 30);
            this.lbTacGia.TabIndex = 5;
            this.lbTacGia.Text = "Tác giả:";
            this.lbTacGia.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbSoLuong
            // 
            this.lbSoLuong.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoLuong.ForeColor = System.Drawing.Color.DarkBlue;
            this.lbSoLuong.Location = new System.Drawing.Point(558, 118);
            this.lbSoLuong.Name = "lbSoLuong";
            this.lbSoLuong.Size = new System.Drawing.Size(150, 30);
            this.lbSoLuong.TabIndex = 5;
            this.lbSoLuong.Text = "Số Lượng:";
            this.lbSoLuong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTenSach
            // 
            this.lbTenSach.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenSach.ForeColor = System.Drawing.Color.Navy;
            this.lbTenSach.Location = new System.Drawing.Point(43, 124);
            this.lbTenSach.Name = "lbTenSach";
            this.lbTenSach.Size = new System.Drawing.Size(150, 30);
            this.lbTenSach.TabIndex = 5;
            this.lbTenSach.Text = "Tên Sách:";
            this.lbTenSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbNXB
            // 
            this.lbNXB.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNXB.ForeColor = System.Drawing.Color.DarkBlue;
            this.lbNXB.Location = new System.Drawing.Point(558, 42);
            this.lbNXB.Name = "lbNXB";
            this.lbNXB.Size = new System.Drawing.Size(150, 30);
            this.lbNXB.TabIndex = 5;
            this.lbNXB.Text = "Nhà Xuất Bản:";
            this.lbNXB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbLoaiSach
            // 
            this.lbLoaiSach.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoaiSach.ForeColor = System.Drawing.Color.Navy;
            this.lbLoaiSach.Location = new System.Drawing.Point(43, 42);
            this.lbLoaiSach.Name = "lbLoaiSach";
            this.lbLoaiSach.Size = new System.Drawing.Size(150, 30);
            this.lbLoaiSach.TabIndex = 5;
            this.lbLoaiSach.Text = "Loại Sách:";
            this.lbLoaiSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(50)))), ((int)(((byte)(49)))));
            this.btnXoa.FlatAppearance.BorderSize = 0;
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnXoa.Location = new System.Drawing.Point(1052, 192);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(120, 40);
            this.btnXoa.TabIndex = 9;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(238)))), ((int)(((byte)(24)))));
            this.btnSua.FlatAppearance.BorderSize = 0;
            this.btnSua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSua.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSua.Location = new System.Drawing.Point(1052, 114);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(120, 40);
            this.btnSua.TabIndex = 8;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(175)))), ((int)(((byte)(75)))));
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnThem.Location = new System.Drawing.Point(1052, 36);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(120, 40);
            this.btnThem.TabIndex = 7;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            // 
            // FAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FAdmin";
            this.Text = "FAdmin";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txbGiaTien;
        private System.Windows.Forms.TextBox txbTacGia;
        private System.Windows.Forms.TextBox txbSoLuong;
        private System.Windows.Forms.TextBox txbTenSach;
        private System.Windows.Forms.TextBox txbNXB;
        private System.Windows.Forms.TextBox txbLoaiSach;
        private System.Windows.Forms.Label lbGiaTien;
        private System.Windows.Forms.Label lbTacGia;
        private System.Windows.Forms.Label lbSoLuong;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.Label lbNXB;
        private System.Windows.Forms.Label lbLoaiSach;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
    }
}