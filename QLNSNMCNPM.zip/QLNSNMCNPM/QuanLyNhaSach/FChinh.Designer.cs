﻿namespace QuanLyNhaSach
{
    partial class FChinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FChinh));
            this.pnThanh = new System.Windows.Forms.Panel();
            this.pnTrang = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnTaiKhoan = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnCaiDat = new System.Windows.Forms.Button();
            this.btnThemDL = new System.Windows.Forms.Button();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnNhapSach = new System.Windows.Forms.Button();
            this.btnKeSach = new System.Windows.Forms.Button();
            this.btnBanSach = new System.Windows.Forms.Button();
            this.pnChinh = new System.Windows.Forms.Panel();
            this.pnThanh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnThanh
            // 
            this.pnThanh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.pnThanh.Controls.Add(this.pnTrang);
            this.pnThanh.Controls.Add(this.label1);
            this.pnThanh.Controls.Add(this.pictureBox2);
            this.pnThanh.Controls.Add(this.btnTaiKhoan);
            this.pnThanh.Controls.Add(this.btnThoat);
            this.pnThanh.Controls.Add(this.btnCaiDat);
            this.pnThanh.Controls.Add(this.btnThemDL);
            this.pnThanh.Controls.Add(this.btnThongKe);
            this.pnThanh.Controls.Add(this.btnNhapSach);
            this.pnThanh.Controls.Add(this.btnKeSach);
            this.pnThanh.Controls.Add(this.btnBanSach);
            this.pnThanh.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnThanh.Location = new System.Drawing.Point(0, 0);
            this.pnThanh.Name = "pnThanh";
            this.pnThanh.Size = new System.Drawing.Size(200, 720);
            this.pnThanh.TabIndex = 2;
            // 
            // pnTrang
            // 
            this.pnTrang.BackColor = System.Drawing.Color.White;
            this.pnTrang.Location = new System.Drawing.Point(0, 173);
            this.pnTrang.Name = "pnTrang";
            this.pnTrang.Size = new System.Drawing.Size(5, 60);
            this.pnTrang.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "KVC BOOK SHOP";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(22, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(155, 131);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // btnTaiKhoan
            // 
            this.btnTaiKhoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btnTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaiKhoan.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaiKhoan.ForeColor = System.Drawing.Color.White;
            this.btnTaiKhoan.Image = ((System.Drawing.Image)(resources.GetObject("btnTaiKhoan.Image")));
            this.btnTaiKhoan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTaiKhoan.Location = new System.Drawing.Point(5, 238);
            this.btnTaiKhoan.Name = "btnTaiKhoan";
            this.btnTaiKhoan.Size = new System.Drawing.Size(195, 60);
            this.btnTaiKhoan.TabIndex = 0;
            this.btnTaiKhoan.Text = "Tài Khoản";
            this.btnTaiKhoan.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTaiKhoan.UseVisualStyleBackColor = false;
            this.btnTaiKhoan.Click += new System.EventHandler(this.btnTaiKhoan_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnThoat.FlatAppearance.BorderSize = 0;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.White;
            this.btnThoat.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat.Image")));
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(5, 630);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(195, 60);
            this.btnThoat.TabIndex = 0;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnCaiDat
            // 
            this.btnCaiDat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnCaiDat.FlatAppearance.BorderSize = 0;
            this.btnCaiDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaiDat.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaiDat.ForeColor = System.Drawing.Color.White;
            this.btnCaiDat.Image = ((System.Drawing.Image)(resources.GetObject("btnCaiDat.Image")));
            this.btnCaiDat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCaiDat.Location = new System.Drawing.Point(5, 564);
            this.btnCaiDat.Name = "btnCaiDat";
            this.btnCaiDat.Size = new System.Drawing.Size(195, 60);
            this.btnCaiDat.TabIndex = 0;
            this.btnCaiDat.Text = "Cài Đặt";
            this.btnCaiDat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCaiDat.UseVisualStyleBackColor = false;
            this.btnCaiDat.Click += new System.EventHandler(this.btnCaiDat_Click);
            // 
            // btnThemDL
            // 
            this.btnThemDL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnThemDL.FlatAppearance.BorderSize = 0;
            this.btnThemDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemDL.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemDL.ForeColor = System.Drawing.Color.White;
            this.btnThemDL.Image = ((System.Drawing.Image)(resources.GetObject("btnThemDL.Image")));
            this.btnThemDL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemDL.Location = new System.Drawing.Point(5, 498);
            this.btnThemDL.Name = "btnThemDL";
            this.btnThemDL.Size = new System.Drawing.Size(195, 60);
            this.btnThemDL.TabIndex = 0;
            this.btnThemDL.Text = "Thêm Dữ Liệu";
            this.btnThemDL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThemDL.UseVisualStyleBackColor = false;
            this.btnThemDL.Click += new System.EventHandler(this.btnThemDL_Click);
            // 
            // btnThongKe
            // 
            this.btnThongKe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnThongKe.FlatAppearance.BorderSize = 0;
            this.btnThongKe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThongKe.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.ForeColor = System.Drawing.Color.White;
            this.btnThongKe.Image = ((System.Drawing.Image)(resources.GetObject("btnThongKe.Image")));
            this.btnThongKe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThongKe.Location = new System.Drawing.Point(5, 433);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(195, 60);
            this.btnThongKe.TabIndex = 0;
            this.btnThongKe.Text = "Thống Kê";
            this.btnThongKe.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThongKe.UseVisualStyleBackColor = false;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnNhapSach
            // 
            this.btnNhapSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnNhapSach.FlatAppearance.BorderSize = 0;
            this.btnNhapSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapSach.ForeColor = System.Drawing.Color.White;
            this.btnNhapSach.Image = ((System.Drawing.Image)(resources.GetObject("btnNhapSach.Image")));
            this.btnNhapSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhapSach.Location = new System.Drawing.Point(5, 368);
            this.btnNhapSach.Name = "btnNhapSach";
            this.btnNhapSach.Size = new System.Drawing.Size(195, 60);
            this.btnNhapSach.TabIndex = 0;
            this.btnNhapSach.Text = "Nhập Sách";
            this.btnNhapSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNhapSach.UseVisualStyleBackColor = false;
            this.btnNhapSach.Click += new System.EventHandler(this.btnNhapSach_Click);
            // 
            // btnKeSach
            // 
            this.btnKeSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnKeSach.FlatAppearance.BorderSize = 0;
            this.btnKeSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeSach.ForeColor = System.Drawing.Color.White;
            this.btnKeSach.Image = ((System.Drawing.Image)(resources.GetObject("btnKeSach.Image")));
            this.btnKeSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKeSach.Location = new System.Drawing.Point(5, 303);
            this.btnKeSach.Name = "btnKeSach";
            this.btnKeSach.Size = new System.Drawing.Size(195, 60);
            this.btnKeSach.TabIndex = 0;
            this.btnKeSach.Text = "Kệ Sách";
            this.btnKeSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnKeSach.UseVisualStyleBackColor = false;
            this.btnKeSach.Click += new System.EventHandler(this.btnKeSach_Click);
            // 
            // btnBanSach
            // 
            this.btnBanSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.btnBanSach.FlatAppearance.BorderSize = 0;
            this.btnBanSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBanSach.ForeColor = System.Drawing.Color.White;
            this.btnBanSach.Image = ((System.Drawing.Image)(resources.GetObject("btnBanSach.Image")));
            this.btnBanSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBanSach.Location = new System.Drawing.Point(5, 173);
            this.btnBanSach.Name = "btnBanSach";
            this.btnBanSach.Size = new System.Drawing.Size(195, 60);
            this.btnBanSach.TabIndex = 0;
            this.btnBanSach.Text = "Bán Sách";
            this.btnBanSach.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBanSach.UseVisualStyleBackColor = false;
            this.btnBanSach.Click += new System.EventHandler(this.btnBanSach_Click);
            // 
            // pnChinh
            // 
            this.pnChinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnChinh.Location = new System.Drawing.Point(200, 0);
            this.pnChinh.Name = "pnChinh";
            this.pnChinh.Size = new System.Drawing.Size(1000, 720);
            this.pnChinh.TabIndex = 3;
            // 
            // FChinh
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 720);
            this.Controls.Add(this.pnChinh);
            this.Controls.Add(this.pnThanh);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FChinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Màn Hình Chính";
            this.pnThanh.ResumeLayout(false);
            this.pnThanh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnThanh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnThemDL;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnNhapSach;
        private System.Windows.Forms.Button btnKeSach;
        private System.Windows.Forms.Button btnBanSach;
        private System.Windows.Forms.Button btnTaiKhoan;
        private System.Windows.Forms.Button btnCaiDat;
        private System.Windows.Forms.Panel pnTrang;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Panel pnChinh;
    }
}